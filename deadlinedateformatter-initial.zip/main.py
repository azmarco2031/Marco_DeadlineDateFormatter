from datetime import datetime
import calendar

event_title = str(input("Enter event title: ")).strip().upper()
year = int(input("Enter year: "))
month = int(input("Enter month: "))
day = int(input("Enter day: "))
event_date = datetime(year, month, day)
month_name = calendar.month_name[month]
day_name = calendar.day_name[day - 1]

print()
print("Formatted Output:")
print("Event:", event_title)
print("Date:", event_date.strftime("%B %d, %Y"))
print("Year:", year)
print("Month:", month_name)
print("Day:", day)
print("Weekday:", day_name)
