from datetime import datetime
import calendar

event_title = str(input("Enter event title: ")).strip().upper()
year = int(input("Enter year: "))
month = int(input("Enter month: "))
day = int(input("Enter day: "))
